Name: Sunny Qi

Brick Breaker

This is a basic game of brick breaker.
-The smiley face acts as the ball, and there are rectangles as the bricks and paddle.
-Brick colors are generated at random, and each game starts with 15 bricks.
-The paddle can be moved left and right as controlled by the left and right arrow keys.
-To start the game from the start screen, press START
-To restart the game, press select at any time to return to the start screen.

-Note* There is a short delay (about 1 second) before the ball starts moving and the game begins.
-This delay is to give a player a chance to get ready to play.
=========================
SCORING:
-Breaking a pink brick earns you 3 points
-Breaking any other brick earns you 1 point

ENDING THE GAME:
-Player loses if they drop the ball (let it fall off the screen) 
-Game ends and player wins when all bricks are broken.


Note* The yellow brick bomb feature mentioned in the start screen doesn't actually work yet, this game is incomplete